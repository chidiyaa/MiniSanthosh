package com.cg.rms.service;

import com.cg.rms.exception.RecruitmentException;

public interface PlacedCandidateService {
	public int pCountMonth(String month) throws RecruitmentException;
	public int pCountCompany(String Company) throws RecruitmentException;
	public int pCountDesignation(String designation) throws RecruitmentException;

}
