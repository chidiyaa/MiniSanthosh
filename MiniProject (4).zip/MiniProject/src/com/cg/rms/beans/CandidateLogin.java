package com.cg.rms.beans;

public class CandidateLogin {
	private String userName;
	private String password;
	@Override
	public String toString() {
		return "CandidateLogin [userName=" + userName + ", password="
				+ password + "]";
	}
	public CandidateLogin() {
		super();
	}
	public CandidateLogin(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
