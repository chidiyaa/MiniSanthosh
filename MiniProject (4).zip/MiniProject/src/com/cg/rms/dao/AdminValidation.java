package com.cg.rms.dao;

import com.cg.rms.exception.RecruitmentException;

public interface AdminValidation {
		public void validateAdmin(String userName,String password) throws RecruitmentException;
}
